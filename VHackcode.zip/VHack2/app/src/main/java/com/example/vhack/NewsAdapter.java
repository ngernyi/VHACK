package com.example.vhack;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {

    private List<Newslist> dataList; // Replace DataModel with the type of data model you have

    public NewsAdapter(List<Newslist> dataList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Newslist data = dataList.get(position);
        holder.bind(data);
    }

    // Method to add a single news item to the list
    public void addDataItem(Newslist newsItem) {
        if (dataList == null) {
            dataList = new ArrayList<>();
        }
        dataList.add(newsItem);
        // Notify the adapter that a new item has been added
        notifyItemInserted(dataList.size() - 1);
    }
    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView date;
        private TextView title;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.TVDate); // Replace textView1 with the ID of the first TextView in item_layout.xml
            title = itemView.findViewById(R.id.TVTitle); // Replace textView2 with the ID of the second TextView in item_layout.xml
        }

        public void bind(Newslist data) {
            date.setText(data.getDate());
            title.setText(data.getTitle());
        }
    }
}
