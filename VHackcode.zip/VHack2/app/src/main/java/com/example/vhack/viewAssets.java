package com.example.vhack;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class viewAssets extends DialogFragment {

    private View closeButton;

//    @NonNull
//    @Override
//    public Dialog onCreateDialog(Bundle savedInstanceState) {
//        // Create a custom dialog without the title
//        Dialog dialog = new Dialog(requireContext());
//        dialog.setContentView(R.layout.fragment_view_assets);
//        return dialog;
//    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_assets, container, false);

        // Get the reference to the close button
//        closeButton = view.findViewById(R.id.closeViewAssets);
//
//        // Set click listener for the close button
//        closeButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Dismiss the dialog when the close button is clicked
//                dismiss();
//            }
//        });

        return view;
    }
}
