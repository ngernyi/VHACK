package com.example.vhack;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class dashboard extends Fragment {

    TextView ana;
    TextView ins;
    TextView port;
    TextView up;
    TextView profile;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ana = view.findViewById(R.id.TVana);
        ins = view.findViewById(R.id.TVINs);
        port = view.findViewById(R.id.TVPort);
        up = view.findViewById(R.id.TVtopremium);
        profile = view.findViewById(R.id.TVprofile);

        ins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                investmentInfo investmentInfo = new investmentInfo();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, investmentInfo);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });


        ana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                analyticBoard analyticBoard = new analyticBoard();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, analyticBoard);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });

        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                premiumPage analyticBoard = new premiumPage();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, analyticBoard);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                profile profile = new profile();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, profile);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });
    }
}
