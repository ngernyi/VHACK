package com.example.vhack;

public class Newslist {

    private int newsId;
    private int impact;
    private String date;
    private String title;

    public Newslist(int id, String date, String title, int impact) {
        this.newsId = id;
        this.impact = impact;
        this.date = date;
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
