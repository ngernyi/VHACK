package com.example.vhack;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link popupMakeChanges#newInstance} factory method to
 * create an instance of this fragment.
 */
public class popupMakeChanges extends DialogFragment {

    View company1;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_popup_make_changes, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        company1 = view.findViewById(R.id.Company1);
        company1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPopupWindow(); // Pass the button view as the parent view
            }
        });
    }

    private void showPopupWindow() {
        // Inflate the layout for the popup window
        // Show the pop-up window when the MapFragment is created
        View popupView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_add_or_minus, null);
        final PopupWindow popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        // Show the pop-up window at the center of the screen
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

        // Set an OnClickListener to dismiss the pop-up window when clicked
        popupView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();

            }
        });
    }
}