package com.example.vhack;

import android.media.Image;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.FragmentTransaction;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link landingPage#newInstance} factory method to
 * create an instance of this fragment.
 */
public class landingPage extends Fragment {

    ImageView dash;
    TextView arena;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_landing_page, container, false);

        // Find the button
        ImageView playButton = rootView.findViewById(R.id.ImagePlayButton);
        dash = rootView.findViewById(R.id.ImageToDashboard);
        arena = rootView.findViewById(R.id.TVarena);

        arena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                arenaPage arenaPage = new arenaPage();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, arenaPage);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });

        dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                dashboard dashboard = new dashboard();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, dashboard);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });
        // Set click listener for the button
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the destination fragment
                map map = new map();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, map);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });

        return rootView;
    }
}