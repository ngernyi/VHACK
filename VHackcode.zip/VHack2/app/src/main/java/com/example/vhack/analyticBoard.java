package com.example.vhack;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class analyticBoard extends Fragment {

    TextView closeAna; // Make sure this matches the ID in your XML layout

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_analytic_board, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Find the CloseAna TextView by its ID
        closeAna = view.findViewById(R.id.CloseAna);

        // Set OnClickListener for the CloseAna TextView
        closeAna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform actions when the CloseAna TextView is clicked
                // For example, you can navigate to another fragment or perform any other action
                landingPage landingPage = new landingPage();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, landingPage);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        });
    }
}
