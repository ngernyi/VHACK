package com.example.vhack;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

import static androidx.core.content.ContextCompat.getSystemService;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.CountDownTimer;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link map#newInstance} factory method to
 * create an instance of this fragment.
 */
public class map extends Fragment {

    private RecyclerView recyclerView;
    private TextView countdownTextView;
    private CountDownTimer countDownTimer;
    private View newsButton; // Rename to newsButton for consistency
    List<Newslist> newsList;
    private int currentNewsIndex = 0;
    private NewsAdapter adapter;

    private View investedAssets;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        countdownTextView = view.findViewById(R.id.TVtimeremaining);
        investedAssets = view.findViewById(R.id.VInvestedAssets);

        investedAssets.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showPopupWindow(); // Pass the button view as the parent view
            }
        });


        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize newsButton (or any trigger view)
        newsButton = view.findViewById(R.id.NewsClickable);
        newsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleRecyclerViewVisibility();
            }
        });

        // Initialize newsList
        newsList = new ArrayList<>();

        // Initialize the adapter
        adapter = new NewsAdapter(newsList);
        recyclerView.setAdapter(adapter);

        // Show the pop-up window when the MapFragment is created
        View popupView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_tuto_before_game, null);
        final PopupWindow popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        // Show the pop-up window at the center of the screen
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

        // Set an OnClickListener to dismiss the pop-up window when clicked
        popupView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                startCountdownTimer();
            }
        });

        // Start displaying news items
        showNextNewsItem();
    }

    private void showPopupWindow() {
        // Inflate the layout for the popup window
        // Show the pop-up window when the MapFragment is created
        View popupView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_view_assets, null);
        final PopupWindow popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        // Show the pop-up window at the center of the screen
        popupWindow.showAtLocation(popupView, Gravity.CENTER, 0, 0);

        // Set an OnClickListener to dismiss the pop-up window when clicked
        popupView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();

            }
        });
    }





    private void showNextNewsItem() {
        // Check if there are more news items to display
        if (currentNewsIndex < newsList.size()) {
            // Get the next news item
            Newslist nextNewsItem = newsList.get(currentNewsIndex);

            // Increment the index for the next news item
            currentNewsIndex++;

            // Add the next news item to the adapter
            NewsAdapter adapter = (NewsAdapter) recyclerView.getAdapter();
            adapter.addDataItem(nextNewsItem);

            // Schedule the next news item to be shown after 10 seconds
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    showNextNewsItem();
                }
            }, 10000); // 10 seconds delay
        }
    }



    private void toggleRecyclerViewVisibility() {
        // Toggle visibility of the RecyclerView
        if (recyclerView.getVisibility() == View.VISIBLE) {
            recyclerView.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            // Display the news list when the RecyclerView becomes visible
            displayNews();
        }
    }

    private void displayNews() {
        // Create dummy news data (replace this with your actual news data)

        newsList.add(new Newslist(1, "23/3", "Nike faces backlash over controversial marketing campaign", -16));
        newsList.add(new Newslist(2, "24/3", "RapidKL experiences service disruptions due to labor strikes", -13));
        newsList.add(new Newslist(3, "25/3", "Tesla CEO arrested for securities fraud", -20));
        newsList.add(new Newslist(4, "26/3", "Milo's revolutionary new product wins industry award", +15));
        newsList.add(new Newslist(5, "27/3", "Tesla reports record-breaking quarter with surge in solar panels", +16));
        newsList.add(new Newslist(6, "28/3", "RapidKL expands services to underserved communities", +18));
        newsList.add(new Newslist(7, "29/3", "Milo recalls popular product due to packaging defect", -12));
        newsList.add(new Newslist(8, "30/3", "Nike unveils innovative sports apparel technology", +14));
        newsList.add(new Newslist(9, "31/3", "RapidKL involved in fatal accident", -25));
        newsList.add(new Newslist(10, "1/4", "Milo's new sustainable farming practices lead to emission cut", +17));
        newsList.add(new Newslist(11, "2/4", "Nike's revenue forecast lowered due to supply chain disruptions", -11));
        newsList.add(new Newslist(12, "3/4", "Milo's manufacturing plant shut down due to environmental issues", -23));
        newsList.add(new Newslist(13, "4/4", "Milo introduces new line of organic snacks", +13));
        newsList.add(new Newslist(14, "5/4", "RapidKL fined for safety violations", -14));
        newsList.add(new Newslist(15, "6/4", "Tesla achieves milestone in autonomous driving technology", +22));
        newsList.add(new Newslist(16, "7/4", "Milo implicated in major food contamination scandal", -22));
        newsList.add(new Newslist(17, "8/4", "Nike sued for workplace discrimination", -18));
        newsList.add(new Newslist(18, "9/4", "Tesla's flagship vehicle model fails safety tests", -21));
        newsList.add(new Newslist(19, "10/4", "Tesla faces production delays for flagship vehicle", -10));
        newsList.add(new Newslist(20, "11/4", "RapidKL faces class-action lawsuit over data breach", -24));
        newsList.add(new Newslist(21, "12/4", "RapidKL awarded $1 billion government contract", +25));
        newsList.add(new Newslist(22, "13/4", "Nike loses major sponsorship deal with sports league", -17));
        newsList.add(new Newslist(23, "14/4", "Nike launches limited edition sneaker collaboration", +12));
        newsList.add(new Newslist(24, "15/4", "Tesla sued for patent infringement by competitor", -15));
        newsList.add(new Newslist(25, "16/4", "Milo's CEO resigns amid financial irregularities investigation", -18));
        newsList.add(new Newslist(26, "17/4", "Nike secures exclusive sponsorship deal with Olympic athlete", +18));
        newsList.add(new Newslist(27, "18/4", "Tesla announces breakthrough in battery technology", +20));
        newsList.add(new Newslist(28, "19/4", "RapidKL receives international recognition for service quality", +19));
        newsList.add(new Newslist(29, "20/4", "Milo introduces new line of organic snacks", +13));
        newsList.add(new Newslist(30, "21/4", "Nike unveils innovative sports apparel technology", +14));

        // Create an adapter for the RecyclerView and pass the news data
        NewsAdapter adapter = new NewsAdapter(newsList);
        recyclerView.setAdapter(adapter);
    }


    private void startCountdownTimer() {
        // Define the duration of the countdown timer in milliseconds (6 minutes)
        long durationInMillis = 15 * 1000; // 6 minutes in milliseconds

        // Define the interval for the countdown timer to update the UI (e.g., every second)
        long intervalInMillis = 1000; // 1 second in milliseconds

        countDownTimer = new CountDownTimer(durationInMillis, intervalInMillis) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Update the UI with the remaining time
                long totalSecondsRemaining = millisUntilFinished / 1000;
                long minutesRemaining = totalSecondsRemaining / 60;
                long secondsRemaining = totalSecondsRemaining % 60;

                // Format the time remaining as "mm:ss" and update the UI
                String formattedTime = String.format("%02d:%02d", minutesRemaining, secondsRemaining);
                countdownTextView.setText(formattedTime);
            }

            @Override
            public void onFinish() {
                // Navigate to the next fragment
                analyticBoard analyticBoard = new analyticBoard();
                FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, analyticBoard);
                transaction.addToBackStack(null);  // Add transaction to the back stack
                transaction.commit();
            }
        };

        // Start the countdown timer
        countDownTimer.start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Cancel the countdown timer to avoid memory leaks
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}